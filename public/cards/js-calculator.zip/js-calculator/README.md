#Calculator made with HTML, CSS, Javascript, and jQuery.

##Allows for the user to click on the numbers or functions and execute the expression. Also will allow from the user to use the keyboard to enter numbers or operators.

