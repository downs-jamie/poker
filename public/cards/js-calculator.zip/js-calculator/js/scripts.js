$(document).ready(function(){

// WHERE YOUR STUFF GOES!!!
function doIt(){
	var total = eval($('.screen').val());
	$('.screen').val(total);
	if(total == 42){
		// $('#meaning').animate({left: '2000px'})
		$('#meaning').addClass('move');
	}
}

	// Make it work on both click and enter key.
	// Need two listeners... 
	// 1. a click for the buttons
	// 2. a keydown listener for the keys

	document.onkeyup = keyCheck;
	// If the user clicks on a button... check to see what it was
	$('.operator, .number').click(function(){
		if($(this).hasClass('equal')){
			// alert("you hit the equal sign!!");
			doIt();
		}else if($(this).hasClass('clear')){
			$('.screen').val('');
		}else{
			var currScreenVal = $('.screen').val();
			console.log($(this).val());
			if($(this).attr('robsStupidAttribute') == 'Mult'){
				$('.screen').val(currScreenVal + '*');	
				console.log($(this).attr('robsStupidAttribute'));
			}else{
				$('.screen').val(currScreenVal + $(this).val());
			}
		}
	});

	//Listen for numbers
	function keyCheck(){
		var keyID = event.keyCode;
		console.log(keyID);
		var currScreenVal = $('.screen').val();
		switch(keyID){
			case 48:
				$('.screen').val(currScreenVal + 0);
				break;
			case 49:
				$('.screen').val(currScreenVal + 1);
				break;
			case 50:
				$('.screen').val(currScreenVal + 2);	
				break;
			case 51:
				$('.screen').val(currScreenVal + 3);	
				break;
			case 52:
				$('.screen').val(currScreenVal + 4);	
				break;
			case 53:
				$('.screen').val(currScreenVal + 5);	
				break;
			case 54:
				$('.screen').val(currScreenVal + 6);	
				break;
			case 55:
				$('.screen').val(currScreenVal + 7);
				break;
			case 56:
				$('.screen').val(currScreenVal + 8);	
				break;
			case 57:
				$('.screen').val(currScreenVal + 9);
				break;
			case 88: 
				$('.screen').val(currScreenVal + '*');	
				break;			
			case 191: 
				$('.screen').val(currScreenVal + '/');	
				break;				
			case 189: 
				$('.screen').val(currScreenVal + '-');	
				break;
			case 107:
				$('.screen').val(currScreenVal + '+');	
				break;	
			// if user hits enter, execute						
			case 187:
				//equal sign
				doIt();
				break;
			case 13:
				//enter sign
				doIt();
				break;
			default:
				// alerD7+lt('huh?');
		}
	}
})








